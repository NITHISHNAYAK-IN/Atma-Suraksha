package IN.SSAPP;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.Button;
import java.util.Timer;
import java.util.TimerTask;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.Context;
import android.os.Vibrator;
import android.view.View;
import java.text.DecimalFormat;
import android.content.ClipboardManager;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;


public class MainActivity extends  AppCompatActivity  { 
	
	public final int REQ_CD_IMAGES_P = 101;
	public final int REQ_CD_IMAGES2_P = 102;
	public final int REQ_CD_IMAGES3_P = 103;
	public final int REQ_CD_IMAGES4_P = 104;
	public final int REQ_CD_IMAGES5_P = 105;
	private Timer _timer = new Timer();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private String latitude = "";
	private String longitude = "";
	private String accuracy = "";
	private String phone_info = "";
	private String imgp1 = "";
	
	private ArrayList<String> imgp2 = new ArrayList<>();
	
	private LinearLayout linear12;
	private ScrollView vscroll1;
	private TextView textview14;
	private TextView textview15;
	private TextView textview16;
	private LinearLayout linear1;
	private LinearLayout linear18;
	private LinearLayout linear10;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear11;
	private ImageView imageview7;
	private LinearLayout linear19;
	private Button button1;
	private TextView textview1;
	private Button button3;
	private Button button4;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private LinearLayout linear6;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private ImageView imageview2;
	private TextView textview2;
	private TextView textview3;
	private ImageView imageview3;
	private TextView textview4;
	private TextView textview5;
	private ImageView imageview4;
	private TextView textview6;
	private TextView textview7;
	private ImageView imageview6;
	private TextView textview8;
	private TextView textview9;
	private ImageView imageview5;
	private TextView textview10;
	private TextView textview11;
	private LinearLayout linear14;
	
	private TimerTask t1;
	private AlertDialog.Builder dialog;
	private Intent intent = new Intent();
	private LocationManager location;
	private LocationListener _location_location_listener;
	private SharedPreferences data;
	private RequestNetwork network;
	private RequestNetwork.RequestListener _network_request_listener;
	private Intent drawer_int = new Intent();
	private AlertDialog.Builder D2;
	private AlertDialog.Builder exit;
	private Intent drawer_int2 = new Intent();
	private AlertDialog.Builder Open_d;
	private SharedPreferences img;
	private Intent images_p = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent images2_p = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent images3_p = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent images4_p = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent images5_p = new Intent(Intent.ACTION_GET_CONTENT);
	private Vibrator vibrator;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_FINE_LOCATION}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		textview14 = (TextView) findViewById(R.id.textview14);
		textview15 = (TextView) findViewById(R.id.textview15);
		textview16 = (TextView) findViewById(R.id.textview16);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		button1 = (Button) findViewById(R.id.button1);
		textview1 = (TextView) findViewById(R.id.textview1);
		button3 = (Button) findViewById(R.id.button3);
		button4 = (Button) findViewById(R.id.button4);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview8 = (TextView) findViewById(R.id.textview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview11 = (TextView) findViewById(R.id.textview11);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		dialog = new AlertDialog.Builder(this);
		location = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
		data = getSharedPreferences("location_data", Activity.MODE_PRIVATE);
		network = new RequestNetwork(this);
		D2 = new AlertDialog.Builder(this);
		exit = new AlertDialog.Builder(this);
		Open_d = new AlertDialog.Builder(this);
		img = getSharedPreferences("img_path", Activity.MODE_PRIVATE);
		images_p.setType("image/*");
		images_p.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		images2_p.setType("image/*");
		images2_p.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		images3_p.setType("image/*");
		images3_p.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		images4_p.setType("image/*");
		images4_p.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		images5_p.setType("image/*");
		images5_p.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
		
		textview16.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				dialog.setTitle("Enter your name here");
				final EditText edittext11=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext11.setLayoutParams(lpar);
				dialog.setView(edittext11);
				dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview16.setText(edittext11.getText());
						data.edit().putString("user", textview16.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		imageview7.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(50));
				D2.setTitle("Are You, Feeling Unsafe/In Danger Now ?");
				D2.setMessage("# If Yes Click On :- \"Help Me\"\n\n# If You Clicked By Mistake Then Please Click On :- \"NO\"");
				D2.setPositiveButton("Help Me", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						if (latitude.contains(".") && longitude.contains(".")) {
							network.startRequestNetwork(RequestNetworkController.GET, "https://nithishnayak.in", "nreq", _network_request_listener);
							if (SketchwareUtil.isConnected(getApplicationContext())) {
								intent.setAction(Intent.ACTION_VIEW);
								intent.setData(Uri.parse("smsto:".concat(textview3.getText().toString().concat(";".concat(textview5.getText().toString().concat(";".concat(textview7.getText().toString().concat(";".concat(textview9.getText().toString().concat(";".concat(textview11.getText().toString())))))))))));
								intent.putExtra("sms_body", "Hello, ".concat("I Am, ".concat(textview16.getText().toString().concat("....Look Here  ")).concat(" :- Please Help Me I Am Feeling  Unsafe .....!!")).concat("   Location:- ".concat(textview1.getText().toString()).concat("  Google Map:-".concat("https://maps.google.com/?q=".concat(latitude.concat(",".concat(longitude.concat("      ,#Accuracy Of Location :- ".concat(accuracy.concat("   ,My Phone Charge :- ".concat(textview14.getText().toString().concat(", My Phone Temperature :- ".concat(textview15.getText().toString().concat("  ,Internet Connection :-".concat(" Connection Available")))))))))))))));
								startActivity(intent);
							}
							else {
								for(int _repeat63 = 0; _repeat63 < (int)(3); _repeat63++) {
									SketchwareUtil.showMessage(getApplicationContext(), "Sorry You Are Not Connected To Internet, But don't worry about this.... because \"Google Map Link\" of your current location will be send to your emergency contact numbers !");
								}
								intent.setAction(Intent.ACTION_VIEW);
								intent.setData(Uri.parse("smsto:".concat(textview3.getText().toString().concat(";".concat(textview5.getText().toString().concat(";".concat(textview7.getText().toString().concat(";".concat(textview9.getText().toString().concat(";".concat(textview11.getText().toString())))))))))));
								intent.putExtra("sms_body", "Hello, ".concat("I Am, ".concat(textview16.getText().toString().concat("....Look Here  ")).concat(" :- Please Help Me I Am Feeling  Unsafe .....!!")).concat("   Location:- ".concat(" Unavailable Due To No Internet Service.....").concat("  Google Map:-".concat("https://maps.google.com/?q=".concat(latitude.concat(",".concat(longitude.concat("      ,#Accuracy Of Location :- ".concat(accuracy.concat("   ,My Phone Charge :- ".concat(textview14.getText().toString().concat(", My Phone Temperature :- ".concat(textview15.getText().toString().concat("  ,Internet Connection :-".concat("Not Connected")))))))))))))));
								startActivity(intent);
							}
						}
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "Please Wait While Latitude & Longitude Searching");
						}
					}
				});
				D2.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				D2.create().show();
				return true;
				}
			 });
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (latitude.contains(".") && longitude.contains(".")) {
					intent.setAction(Intent.ACTION_VIEW);
					intent.setData(Uri.parse("https://maps.google.com/?q=".concat(latitude.concat(",".concat(longitude)))));
					startActivity(intent);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Please Wait....");
				}
			}
		});
		
		textview1.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				if (textview1.getText().toString().contains("-")) {
					((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString()));
					SketchwareUtil.showMessage(getApplicationContext(), "Location Copied !!");
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "Please Find Your Location First\nBy clicking On Above Location Finding Location..");
				}
				return true;
				}
			 });
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				location.removeUpdates(_location_location_listener);
				if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
					location.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1, 1, _location_location_listener);
				}
				SketchwareUtil.showMessage(getApplicationContext(), "NETWORK PROVIDER, Process Started !!");
			}
		});
		
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				location.removeUpdates(_location_location_listener);
				if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
					location.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1, 1, _location_location_listener);
				}
				SketchwareUtil.showMessage(getApplicationContext(), "GPS PROVIDER, Process Started !!");
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vibrator.vibrate((long)(25));
				startActivityForResult(images_p, REQ_CD_IMAGES_P);
			}
		});
		
		textview2.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Name Here.");
				final EditText edittext1=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext1.setLayoutParams(lpar);
				dialog.setView(edittext1);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview2.setText(edittext1.getText());
						data.edit().putString("name1", textview2.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		textview3.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Phone Number Here.");
				final EditText edittext2= new
				EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext2.setLayoutParams(lpar);
				dialog.setView(edittext2);
				edittext2.setInputType(InputType.TYPE_CLASS_NUMBER);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview3.setText(edittext2.getText());
						data.edit().putString("number1", edittext2.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		imageview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vibrator.vibrate((long)(25));
				startActivityForResult(images2_p, REQ_CD_IMAGES2_P);
			}
		});
		
		textview4.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Name Here.");
				final EditText edittext3=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext3.setLayoutParams(lpar);
				dialog.setView(edittext3);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview4.setText(edittext3.getText());
						data.edit().putString("name2", textview4.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		textview5.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Phone Number Here.");
				final EditText edittext7= new
				EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext7.setLayoutParams(lpar);
				dialog.setView(edittext7);
				edittext7.setInputType(InputType.TYPE_CLASS_NUMBER);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview5.setText(edittext7.getText());
						data.edit().putString("number2", textview5.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vibrator.vibrate((long)(25));
				startActivityForResult(images3_p, REQ_CD_IMAGES3_P);
			}
		});
		
		textview6.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Name Here.");
				final EditText edittext4=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext4.setLayoutParams(lpar);
				dialog.setView(edittext4);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview6.setText(edittext4.getText());
						data.edit().putString("name3", textview6.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		textview7.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Phone Number Here.");
				final EditText edittext8= new
				EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext8.setLayoutParams(lpar);
				dialog.setView(edittext8);
				edittext8.setInputType(InputType.TYPE_CLASS_NUMBER);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview7.setText(edittext8.getText());
						data.edit().putString("number3", textview7.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vibrator.vibrate((long)(25));
				startActivityForResult(images4_p, REQ_CD_IMAGES4_P);
			}
		});
		
		textview8.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Name Here.");
				final EditText edittext5=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext5.setLayoutParams(lpar);
				dialog.setView(edittext5);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview8.setText(edittext5.getText());
						data.edit().putString("name4", textview8.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		textview9.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Phone Number Here.");
				final EditText edittext9= new
				EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext9.setLayoutParams(lpar);
				dialog.setView(edittext9);
				edittext9.setInputType(InputType.TYPE_CLASS_NUMBER);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview9.setText(edittext9.getText());
						data.edit().putString("number4", textview9.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vibrator.vibrate((long)(25));
				startActivityForResult(images5_p, REQ_CD_IMAGES5_P);
			}
		});
		
		textview10.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Name Here.");
				final EditText edittext6=new EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext6.setLayoutParams(lpar);
				dialog.setView(edittext6);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview10.setText(edittext6.getText());
						data.edit().putString("name5", textview10.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		textview11.setOnLongClickListener(new View.OnLongClickListener() {
			 @Override
				public boolean onLongClick(View _view) {
				vibrator.vibrate((long)(25));
				dialog.setTitle("Please Enter Phone Number Here.");
				final EditText edittext10= new
				EditText(MainActivity.this);
				LinearLayout.LayoutParams lpar = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
				edittext10.setLayoutParams(lpar);
				dialog.setView(edittext10);
				edittext10.setInputType(InputType.TYPE_CLASS_NUMBER);
				dialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						textview11.setText(edittext10.getText());
						data.edit().putString("number5", textview11.getText().toString()).commit();
					}
				});
				dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				dialog.create().show();
				return true;
				}
			 });
		
		_location_location_listener = new LocationListener() {
			@Override
			public void onLocationChanged(Location _param1) {
				final double _lat = _param1.getLatitude();
				final double _lng = _param1.getLongitude();
				final double _acc = _param1.getAccuracy();
				latitude = String.valueOf(_lat);
				longitude = String.valueOf(_lng);
				accuracy = String.valueOf(_acc);
				if (latitude.contains(".") && longitude.contains(".")) {
					textview1.setVisibility(View.VISIBLE);
					_getAddress(textview1, Double.parseDouble(latitude), Double.parseDouble(longitude));
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "please wait");
				}
			}
			@Override
			public void onStatusChanged(String provider, int status, Bundle extras) {}
			@Override
			public void onProviderEnabled(String provider) {}
			@Override
			public void onProviderDisabled(String provider) {}
		};
		
		_network_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_Phone();
		textview1.setVisibility(View.GONE);
		network.startRequestNetwork(RequestNetworkController.GET, "https://nithishnayak.in", "nreq", _network_request_listener);
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			SketchwareUtil.showMessage(getApplicationContext(), "Internet Connected");
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Sorry, No Internet Connection");
		}
		if (true) {
			textview16.setText("Enter Your Name Here");
		}
		else {
			textview16.setText(data.getString("user", ""));
		}
		if (data.getString("name1", "").equals("") && data.getString("number1", "").equals("")) {
			textview2.setText("ENTER NAME");
			textview3.setText("ENTER NUMBER");
		}
		else {
			textview2.setText(data.getString("name1", ""));
			textview3.setText(data.getString("number1", ""));
		}
		if (data.getString("name2", "").equals("") && data.getString("number2", "").equals("")) {
			textview4.setText("ENTER NAME");
			textview5.setText("ENTER NUMBER");
		}
		else {
			textview4.setText(data.getString("name2", ""));
			textview5.setText(data.getString("number2", ""));
		}
		if (data.getString("name3", "").equals("") && data.getString("number3", "").equals("")) {
			textview6.setText("ENTER NAME");
			textview7.setText("ENTER NUMBER");
		}
		else {
			textview6.setText(data.getString("name3", ""));
			textview7.setText(data.getString("number3", ""));
		}
		if (data.getString("name4", "").equals("") && data.getString("number4", "").equals("")) {
			textview8.setText("ENTER NAME");
			textview9.setText("ENTER NUMBER");
		}
		else {
			textview8.setText(data.getString("name4", ""));
			textview9.setText(data.getString("number4", ""));
		}
		if (data.getString("name5", "").equals("") && data.getString("number5", "").equals("")) {
			textview10.setText("ENTER NAME");
			textview11.setText("ENTER NUMBER");
		}
		else {
			textview10.setText(data.getString("name5", ""));
			textview11.setText(data.getString("number5", ""));
		}
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_IMAGES_P:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img.edit().putString("eimg1", _filePath.get((int)(0))).commit();
				imageview2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg1", ""), 1024, 1024));
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMAGES2_P:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img.edit().putString("eimg2", _filePath.get((int)(0))).commit();
				imageview3.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg2", ""), 1024, 1024));
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMAGES3_P:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img.edit().putString("eimg3", _filePath.get((int)(0))).commit();
				imageview4.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg3", ""), 1024, 1024));
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMAGES4_P:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img.edit().putString("eimg4", _filePath.get((int)(0))).commit();
				imageview6.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg4", ""), 1024, 1024));
			}
			else {
				
			}
			break;
			
			case REQ_CD_IMAGES5_P:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				img.edit().putString("eimg5", _filePath.get((int)(0))).commit();
				imageview5.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg5", ""), 1024, 1024));
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		exit.setTitle("Are You Sure Want To Exit ??");
		exit.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "Thank You");
				finishAffinity();
			}
		});
		exit.setNegativeButton("No", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				SketchwareUtil.showMessage(getApplicationContext(), "cancelled");
			}
		});
		exit.create().show();
	}
	
	@Override
	public void onStart() {
		super.onStart();
		if (img.getString("eimg1", "").equals("")) {
			
		}
		else {
			imageview2.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg1", ""), 1024, 1024));
		}
		if (img.getString("eimg2", "").equals("")) {
			
		}
		else {
			imageview3.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg2", ""), 1024, 1024));
		}
		if (img.getString("eimg3", "").equals("")) {
			
		}
		else {
			imageview4.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg3", ""), 1024, 1024));
		}
		if (img.getString("eimg4", "").equals("")) {
			
		}
		else {
			imageview6.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg4", ""), 1024, 1024));
		}
		if (img.getString("eimg5", "").equals("")) {
			
		}
		else {
			imageview5.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(img.getString("eimg5", ""), 1024, 1024));
		}
	}
	public void _getAddress (final TextView _view, final double _lat, final double _lng) {
		android.location.Address address;
		android.location.Geocoder gc = new android.location.Geocoder(MainActivity.this);
		try{
			if(gc.isPresent()){
				List<android.location.Address>list=
				gc.getFromLocation(_lat,_lng,1);
				address = list.get(0);
				String addressd =
				list.get(0).getAddressLine(0);
				_view.setText(addressd);
			}
		}catch(Exception e){
		}
	}
	
	
	public void _Phone () {
		phone_info = "";
		BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);
		
		int battery_percent = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
		
		textview14.setText(battery_percent + "%");
		IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
		
		Intent batteryStatus = registerReceiver(null, ifilter);
		
		int temp = batteryStatus.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);
		
		float tempTwo = ((float) temp) / 10;
		
		textview15.setText(tempTwo + " °C");
		
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}